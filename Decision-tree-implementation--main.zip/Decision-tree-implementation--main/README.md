# Decision-tree-implementation-

**Company**: CODTECH IT SOLUTIONS 

**Name**: L.Revathi

**Intern ID**: CT08KUW

**Domain Name**: Machine learning 

**Batch Duration**: Jan-10-2025 to feb-10-2025

**Mentor Name**: Neela Santhosh 

# Enter the discription of the task preferred not less than 500 words #
